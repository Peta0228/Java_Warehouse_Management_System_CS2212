# 12_The-Warehouse-Management-System-WMS
Specification and Implementation of a WMS, Coursework of CS2212b.

#### Naming:
- `Proj` Project
- `UC`Use Case
