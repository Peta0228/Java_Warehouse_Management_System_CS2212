package ca.uwo.frontend.interfaces;

/**
 * @author kkontog, ktsiouni, mgrigori
 *
 */
public interface CommandInterface {

}
