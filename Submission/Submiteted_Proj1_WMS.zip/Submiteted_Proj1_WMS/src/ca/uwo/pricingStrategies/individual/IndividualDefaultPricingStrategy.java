package ca.uwo.pricingStrategies.individual;

public class IndividualDefaultPricingStrategy implements  IndividualPricingStrategy {
    @Override
    public double calculate(int quantity, double price) {
        return 0;
    }
}
