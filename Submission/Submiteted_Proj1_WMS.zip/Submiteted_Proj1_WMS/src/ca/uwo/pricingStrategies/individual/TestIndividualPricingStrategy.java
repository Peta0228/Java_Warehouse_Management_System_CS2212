package ca.uwo.pricingStrategies.individual;

public class TestIndividualPricingStrategy implements IndividualPricingStrategy {
    @Override
    public double calculate(int quantity, double price) {
        return 0;
    }
}
